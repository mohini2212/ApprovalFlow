CREATE DATABASE IF NOT EXISTS approvalflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE approvalflow;
CREATE TABLE IF NOT EXISTS users (
 user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','agency','client') NOT NULL DEFAULT 'client',
 account_status ENUM('active','disabled') NOT NULL DEFAULT 'active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creatives (
 creative_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, agency_id INT UNSIGNED NOT NULL,
 client_id INT UNSIGNED NULL, project_name VARCHAR(180) NOT NULL, category VARCHAR(80) DEFAULT '',
 description TEXT, deadline DATE NULL, stored_name VARCHAR(255) NOT NULL, original_name VARCHAR(255) NOT NULL,
 mime_type VARCHAR(100) NOT NULL, file_size BIGINT UNSIGNED NOT NULL,
 status ENUM('Pending','Approved','Changes Requested') NOT NULL DEFAULT 'Pending',
 feedback TEXT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_creative_agency(agency_id), INDEX idx_creative_client(client_id), INDEX idx_creative_status(status),
 CONSTRAINT fk_creative_agency FOREIGN KEY(agency_id) REFERENCES users(user_id),
 CONSTRAINT fk_creative_client FOREIGN KEY(client_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creative_history (
 history_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, creative_id BIGINT UNSIGNED NOT NULL,
 action VARCHAR(40) NOT NULL, feedback TEXT NULL, action_by INT UNSIGNED NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_history_creative(creative_id),
 FOREIGN KEY(creative_id) REFERENCES creatives(creative_id) ON DELETE CASCADE,
 FOREIGN KEY(action_by) REFERENCES users(user_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creative_comments (
 comment_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, creative_id BIGINT UNSIGNED NOT NULL,
 user_id INT UNSIGNED NOT NULL, comment TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_comment_creative(creative_id), FOREIGN KEY(creative_id) REFERENCES creatives(creative_id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(user_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS creative_notifications (
 notification_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL,
 creative_id BIGINT UNSIGNED NULL, message VARCHAR(255) NOT NULL, is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_notification_user(user_id),
 FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
 FOREIGN KEY(creative_id) REFERENCES creatives(creative_id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS subscriptions (
 subscription_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL,
 plan ENUM('Basic','Pro','Premium') NOT NULL, amount DECIMAL(10,2) NOT NULL,
 status ENUM('active','cancelled') NOT NULL DEFAULT 'active', payment_mode ENUM('demo') NOT NULL DEFAULT 'demo',
 demo_reference VARCHAR(40) NOT NULL UNIQUE, started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 cancelled_at DATETIME NULL, INDEX idx_subscription_user(user_id),
 FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;
