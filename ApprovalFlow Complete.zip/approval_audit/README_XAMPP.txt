ApprovalFlow integrated local XAMPP build

This build adds MySQL-backed creative records, server-side uploads, client review actions, comments, notifications, and demo-only subscription records while retaining the existing HTML/CSS layout.

Start with XAMPP_SETUP.txt. Import database/approval_flow.sql before using the app.

The payment flow is deliberately a simulation: it creates a DEMO subscription record only. It does not collect or store card/UPI credentials and cannot charge money.

Do not deploy publicly as-is. Review the security limitations in XAMPP_SETUP.txt first.
