<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$email = strtolower(trim($data['email'] ?? ''));
$password = $data['password'] ?? '';
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !is_string($password) || $password === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Enter a valid email and password.']);
    exit;
}
$stmt = $conn->prepare('SELECT user_id, name, email, password_hash, role, account_status FROM users WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$user || $user['account_status'] !== 'active' || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
    exit;
}
session_regenerate_id(true);
$_SESSION['user'] = [
    'id' => (int)$user['user_id'],
    'name' => $user['name'],
    'email' => $user['email'],
    'role' => $user['role']
];
echo json_encode(['success' => true, 'user' => $_SESSION['user']]);
