<?php
// Shared database + PHP session bootstrap for XAMPP.
mysqli_report(MYSQLI_REPORT_OFF);
ini_set('display_errors', '0');

$isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax'
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$conn = new mysqli('localhost', 'root', '', 'approvalflow');
if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Database connection failed. Check XAMPP MySQL and database setup.']);
    exit;
}
$conn->set_charset('utf8mb4');
