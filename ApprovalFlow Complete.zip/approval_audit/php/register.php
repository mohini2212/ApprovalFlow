<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';

function respond($success, $message, $code = 200) {
    http_response_code($code);
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(false, 'Invalid request method.', 405);
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$name = trim($data['name'] ?? '');
$email = strtolower(trim($data['email'] ?? ''));
$password = $data['password'] ?? '';
$role = $data['role'] ?? '';
if ($name === '' || mb_strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) respond(false, 'Enter a valid name and email address.', 400);
if (!is_string($password) || strlen($password) < 8) respond(false, 'Password must be at least 8 characters.', 400);
if (!in_array($role, ['agency', 'client'], true)) respond(false, 'Invalid account type.', 400);
$stmt = $conn->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1');
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) { $stmt->close(); respond(false, 'This email is already registered.', 409); }
$stmt->close();
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
if (!$stmt) respond(false, 'Unable to prepare account creation.', 500);
$stmt->bind_param('ssss', $name, $email, $hash, $role);
if (!$stmt->execute()) respond(false, 'Could not create account. Please try again.', 500);
$stmt->close();
respond(true, 'Registration successful. Please log in.');
