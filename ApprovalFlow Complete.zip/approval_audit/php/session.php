<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
if (empty($_SESSION['user'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'authenticated' => false, 'message' => 'Not logged in.']);
    exit;
}
echo json_encode(['success' => true, 'authenticated' => true, 'user' => $_SESSION['user']]);
