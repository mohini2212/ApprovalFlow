/* ApprovalFlow server-backed application layer. PHP session + MySQL are authoritative. */
(() => {
 const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function api(action, options={}) { const r=await fetch(`php/api.php?action=${encodeURIComponent(action)}`,{credentials:'same-origin',...options});const j=await r.json();if(!r.ok||!j.success)throw new Error(j.message||'Request failed');return j; }
 const json=data=>({method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 function statusBadge(s){return `<span class="status-badge">${esc(s)}</span>`;}
 function creativeCard(c,review=false){return `<article class="creative-item" style="padding:16px;border:1px solid #e5e7eb;border-radius:12px;margin:10px 0"><div><h3>${esc(c.project_name)}</h3><p>${esc(c.description||c.category||'Creative')}</p><p><b>Client:</b> ${esc(c.client_name||c.client_email||'Not assigned')} · <b>Agency:</b> ${esc(c.agency_name||'')}</p><p>${statusBadge(c.status)}</p><a href="${esc(c.file_url)}" target="_blank" rel="noopener">View file: ${esc(c.original_name)}</a></div>${review&&c.status!=='Approved'?`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button type="button" data-approve="${c.creative_id}">Approve</button><button type="button" data-changes="${c.creative_id}">Request changes</button></div>`:''}<button type="button" data-comment="${c.creative_id}" style="margin-top:8px">Add comment</button></article>`;}
 async function load(){
  let data;try{data=await api('list');}catch(e){console.warn('ApprovalFlow data:',e.message);return;}
  const items=data.items||[];const count=(s)=>items.filter(x=>x.status===s).length;
  ['totalCreatives','totalCount'].forEach(id=>{if($(id))$(id).textContent=items.length;});
  ['pendingCreatives','pendingCount'].forEach(id=>{if($(id))$(id).textContent=count('Pending');});
  ['approvedCreatives','approvedCount'].forEach(id=>{if($(id))$(id).textContent=count('Approved');});
  ['changesCreatives','changesRequested'].forEach(id=>{if($(id))$(id).textContent=count('Changes Requested');});
  const recent=$('recentCreatives');if(recent)recent.innerHTML=items.slice(0,5).map(c=>creativeCard(c)).join('')||'<p class="empty-message">No creatives uploaded yet.</p>';
  const clientList=$('clientList');if(clientList||$('clientTable')){try{const cl=await api('clients');const cs=cl.items||[];if(clientList)clientList.innerHTML=cs.map(c=>`<div class="client-item"><h4>${esc(c.name)}</h4><p>${esc(c.email)}</p></div>`).join('')||'<p class="empty-message">No registered clients found.</p>';const table=$('clientTable');if(table){const body=table.querySelector('tbody')||table;body.innerHTML=cs.map(c=>`<tr><td>${esc(c.name)}</td><td>${esc(c.email)}</td><td>Registered</td></tr>`).join('');}const total=$('totalClients');if(total)total.textContent=cs.length;}catch(e){}}
  const clientArea=$('clientCreativeList')||$('clientCreativeLibrary');if(clientArea)clientArea.innerHTML=items.map(c=>creativeCard(c,true)).join('')||'<p class="empty-message">No creatives assigned to your account yet.</p>';
  if($('clientCreativeLibrary')&&$('clientCreativeList'))$('clientCreativeLibrary').innerHTML=$('clientCreativeList').innerHTML;
  const table=$('projectTable');if(table){const body=table.querySelector('tbody')||table;body.innerHTML=items.map(c=>`<tr><td>${esc(c.project_name)}</td><td>${esc(c.client_name||'—')}</td><td>${esc(c.category)}</td><td>${statusBadge(c.status)}</td><td>${esc(c.created_at)}</td><td><a href="${esc(c.file_url)}" target="_blank">View</a></td></tr>`).join('');}
  const approvalList=$('approvalList');if(approvalList)approvalList.innerHTML=items.map(c=>creativeCard(c,true)).join('')||'<p>No creatives available.</p>';
  const reviewGrid=$('contentGrid');if(reviewGrid)reviewGrid.innerHTML=items.map(c=>creativeCard(c,true)).join('')||'<p class="empty-message">No creatives are waiting for review.</p>';
  const notify=$('notificationCount');if(notify){try{const nr=await api('notifications');notify.textContent=(nr.items||[]).filter(n=>!Number(n.is_read)).length;}catch(e){notify.textContent='0';}}
  const feedback=$('clientFeedbackList');if(feedback){const withFeedback=items.filter(c=>c.feedback);feedback.innerHTML=withFeedback.map(c=>`<div class="activity-item"><b>${esc(c.project_name)}</b><p>${esc(c.feedback)}</p></div>`).join('')||'<p>No feedback available.</p>';}
 }
 document.addEventListener('click',async e=>{
  const a=e.target.closest('[data-approve]'),ch=e.target.closest('[data-changes]'),cm=e.target.closest('[data-comment]');
  try{if(a){if(!confirm('Approve this creative?'))return;await api('status',{...json({id:a.dataset.approve,status:'Approved'})});alert('Creative approved.');await load();}
   if(ch){const feedback=prompt('Describe the changes required:');if(feedback===null)return;if(!feedback.trim())return alert('Feedback is required.');await api('status',{...json({id:ch.dataset.changes,status:'Changes Requested',feedback})});alert('Feedback submitted.');await load();}
   if(cm){const comment=prompt('Write your comment:');if(comment===null||!comment.trim())return;await api('comment',{...json({id:cm.dataset.comment,comment})});alert('Comment saved.');}
  }catch(err){alert(err.message);}
 });
 async function setupUpload(){const form=$('uploadForm');if(!form)return;const clientSelect=$('clientName');if(clientSelect){try{const r=await api('clients');clientSelect.innerHTML='<option value="">Choose registered client</option>'+(r.items||[]).map(c=>`<option value="${esc(c.email)}">${esc(c.name)} (${esc(c.email)})</option>`).join('');}catch(e){}}
  form.addEventListener('submit',async e=>{e.preventDefault();const file=$('fileInput')?.files?.[0];if(!file)return alert('Choose a file first.');if(file.size>10*1024*1024)return alert('File must be 10 MB or smaller.');const fd=new FormData();fd.append('projectName',$('projectName')?.value||'');fd.append('clientEmail',clientSelect?.value||'');fd.append('category',$('category')?.value||'');fd.append('deadline',$('deadline')?.value||'');fd.append('description',$('description')?.value||'');fd.append('creativeFile',file);const btn=form.querySelector('[type=submit]');if(btn)btn.disabled=true;try{const r=await api('upload',{method:'POST',body:fd});alert(r.message);form.reset();await load();}catch(err){alert(err.message);}finally{if(btn)btn.disabled=false;}});
 }
 document.addEventListener('DOMContentLoaded',()=>{setupUpload();load();});
})();
