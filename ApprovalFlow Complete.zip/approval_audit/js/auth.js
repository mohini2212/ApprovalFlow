document.addEventListener('DOMContentLoaded', async function () {
  const isProtectedPage = /(?:agency-dashboard|client-dashboard|admin-dashboard|clients|upload|approvals|review|billing|subscription|setting|payment)\.html$/i.test(window.location.pathname);

  function goToRoleDashboard(role) {
    if (role === 'agency') window.location.href = 'agency-dashboard.html';
    else if (role === 'client') window.location.href = 'client-dashboard.html';
    else if (role === 'admin') window.location.href = 'admin-dashboard.html';
    else window.location.href = 'index.html';
  }

  async function getServerSession() {
    const response = await fetch('php/session.php', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) return null;
    const data = await response.json();
    if (!data.success || !data.user) return null;
    // Kept temporarily because existing dashboard scripts read this cache.
    // The PHP session remains the authentication authority.
    sessionStorage.setItem('currentUser', JSON.stringify(data.user));
    return data.user;
  }

  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    signupForm.addEventListener('submit', async function (event) {
      event.preventDefault();
      const name = document.getElementById('fullName')?.value.trim();
      const email = document.getElementById('email')?.value.trim().toLowerCase();
      const password = document.getElementById('password')?.value;
      const confirmPassword = document.getElementById('confirmPassword')?.value;
      const role = document.getElementById('accountType')?.value;
      const terms = document.getElementById('terms')?.checked;
      if (!name || !email || !password || !confirmPassword) return alert('Please fill in all required fields.');
      if (password.length < 8) return alert('Password must contain at least 8 characters.');
      if (password !== confirmPassword) return alert('Passwords do not match.');
      if (!terms) return alert('Please accept the Terms and Conditions.');
      if (!['agency', 'client'].includes(role)) return alert('Invalid account type.');
      const button = signupForm.querySelector('[type="submit"]');
      if (button) { button.disabled = true; button.dataset.originalText = button.textContent; button.textContent = 'Creating Account...'; }
      try {
        const response = await fetch('php/register.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password, role })
        });
        const result = await response.json();
        if (!response.ok || !result.success) return alert(result.message || 'Registration failed.');
        alert(result.message);
        window.location.href = 'login.html';
      } catch (error) {
        console.error('Registration error:', error);
        alert('Unable to connect. Open this project through XAMPP Apache (http://localhost/...).');
      } finally {
        if (button) { button.disabled = false; button.textContent = button.dataset.originalText || 'Create Account'; }
      }
    });
  }

  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async function (event) {
      event.preventDefault();
      const email = document.getElementById('loginEmail')?.value.trim().toLowerCase();
      const password = document.getElementById('loginPassword')?.value;
      if (!email || !password) return alert('Please enter your email and password.');
      const button = loginForm.querySelector('[type="submit"]');
      if (button) { button.disabled = true; button.dataset.originalText = button.textContent; button.textContent = 'Signing in...'; }
      try {
        const response = await fetch('php/login.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const result = await response.json();
        if (!response.ok || !result.success) return alert(result.message || 'Login failed.');
        sessionStorage.setItem('currentUser', JSON.stringify(result.user));
        alert('Login successful!');
        goToRoleDashboard(result.user.role);
      } catch (error) {
        console.error('Login error:', error);
        alert('Unable to connect. Make sure Apache and MySQL are running in XAMPP.');
      } finally {
        if (button) { button.disabled = false; button.textContent = button.dataset.originalText || 'Login'; }
      }
    });
  }

  document.querySelectorAll('.logout-btn').forEach(button => {
    button.addEventListener('click', async function (event) {
      event.preventDefault();
      try { await fetch('php/logout.php', { method: 'POST', credentials: 'same-origin' }); }
      catch (error) { console.error('Logout error:', error); }
      sessionStorage.removeItem('currentUser');
      window.location.href = 'login.html';
    });
  });

  if (isProtectedPage) {
    try {
      const user = await getServerSession();
      if (!user) {
        sessionStorage.removeItem('currentUser');
        window.location.replace('login.html');
        return;
      }
      const path = window.location.pathname.toLowerCase();
      const requiredRole = path.includes('client-dashboard') || path.includes('review') ? 'client'
        : path.includes('admin-dashboard') ? 'admin'
        : path.includes('agency-dashboard') || path.includes('clients') || path.includes('upload') || path.includes('approvals') || path.includes('billing') || path.includes('subscription') || path.includes('setting') || path.includes('payment') || path.includes('approvals') ? 'agency' : null;
      if (requiredRole && user.role !== requiredRole && user.role !== 'admin') goToRoleDashboard(user.role);
    } catch (error) {
      console.error('Session verification failed:', error);
      window.location.replace('login.html');
    }
  }
});
